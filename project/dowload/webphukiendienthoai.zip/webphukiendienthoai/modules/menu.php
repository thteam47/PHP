   <div class="menu">
        	<ul>
            	<li><a href="index.php">Trang chủ</a></li>
                <li><a href="">Sản phẩm</a></li>
                <li><a href="?quanly=dangkymoi">Đăng ký</a></li>
                 <li><a href="?quanly=dangnhap">Đăng nhập</a></li>
                 <li><a href="?quanly=dathang">Giỏ hàng</a></li>
                <li><a href="">Tin tức </a></li>
                <li><a href="">Liên hệ</a></li>
            </ul>
        </div>