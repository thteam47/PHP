@include('manage.layouts.header')
@yield('content')
@include('manage.layouts.footer')
