<p>{{ $otp }}</p>
<p>{{ $email }}</p>
